<?php
// Import PHPMailer classes manually
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Manual autoloader for PHPMailer
function loadPHPMailer($class) {
    $prefix = 'PHPMailer\\PHPMailer\\';
    $base_dir = __DIR__ . '/../PHPMailer/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
}

spl_autoload_register('loadPHPMailer');

class EmailConfig {
    private $mail;
    
    public function __construct() {
        $this->mail = new PHPMailer(true);
        
        try {
            // Server settings
            $this->mail->isSMTP();
            $this->mail->Host       = 'smtp.gmail.com';
            $this->mail->SMTPAuth   = true;
            $this->mail->Username   = 'ronsardrugirangoga2003@gmail.com';
            $this->mail->Password   = 'your_app_password_here'; // You'll set this
            $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $this->mail->Port       = 587;
            
            // Sender settings
            $this->mail->setFrom('ronsardrugirangoga2003@gmail.com', 'Military Institution IO');
            $this->mail->isHTML(true);
            
        } catch (Exception $e) {
            error_log("PHPMailer Error: " . $e->getMessage());
        }
    }
    
    public function sendGatePassEmail($to_email, $recipient_name, $pass_number, $qr_data, $time_out, $expected_return, $destination, $purpose) {
        try {
            // Recipient
            $this->mail->clearAddresses();
            $this->mail->addAddress($to_email, $recipient_name);
            
            // Content
            $subject = "Military Gate Pass - " . $pass_number;
            $message = $this->generateEmailTemplate($recipient_name, $pass_number, $qr_data, $time_out, $expected_return, $destination, $purpose);
            
            $this->mail->Subject = $subject;
            $this->mail->Body    = $message;
            $this->mail->AltBody = $this->generatePlainTextContent($recipient_name, $pass_number, $time_out, $expected_return, $destination, $purpose);
            
            $this->mail->send();
            error_log("Email sent successfully to: $to_email");
            return true;
            
        } catch (Exception $e) {
            error_log("Email sending failed: " . $this->mail->ErrorInfo);
            
            // Fallback: Save gate pass as HTML file
            $this->saveLocalGatePass($recipient_name, $pass_number, $qr_data, $time_out, $expected_return, $destination, $purpose);
            return false;
        }
    }
    
    private function generateEmailTemplate($recipient_name, $pass_number, $qr_data, $time_out, $expected_return, $destination, $purpose) {
        $time_out_formatted = date('l, F j, Y \a\t g:i A', strtotime($time_out));
        $expected_return_formatted = date('l, F j, Y \a\t g:i A', strtotime($expected_return));
        $purpose_formatted = ucwords(str_replace('_', ' ', $purpose));
        
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
                .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
                .header { background: #2c3e50; color: white; padding: 30px; text-align: center; }
                .content { padding: 30px; }
                .qr-code { text-align: center; margin: 30px 0; padding: 20px; background: #f8f9fa; border-radius: 10px; }
                .details { background: #e8f4fd; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .footer { background: #34495e; color: white; padding: 20px; text-align: center; font-size: 12px; }
                .instruction { background: #fff3cd; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #ffc107; }
                .military-badge { background: #c0392b; color: white; padding: 5px 10px; border-radius: 3px; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <span class='military-badge'>MILITARY INSTITUTION</span>
                    <h1>🚗 GATE PASS</h1>
                    <h2>Pass Number: $pass_number</h2>
                </div>
                
                <div class='content'>
                    <p>Dear <strong>$recipient_name</strong>,</p>
                    <p>Your military gate pass has been generated successfully. Present this QR code at the institution gate.</p>
                    
                    <div class='details'>
                        <h3>📋 Mission Details</h3>
                        <p><strong>Destination:</strong> $destination</p>
                        <p><strong>Purpose:</strong> $purpose_formatted</p>
                        <p><strong>Departure Time:</strong> $time_out_formatted</p>
                        <p><strong>Expected Return:</strong> $expected_return_formatted</p>
                    </div>
                    
                    <div class='qr-code'>
                        <h3>📷 SCAN AT GATE</h3>
                        <div style='background: white; padding: 25px; display: inline-block; border: 3px solid #2c3e50; border-radius: 10px; margin: 15px 0;'>
                            <div style='font-family: monospace; font-size: 16px; letter-spacing: 2px; font-weight: bold; color: #2c3e50; word-break: break-all;'>
                                $qr_data
                            </div>
                            <p style='margin-top: 15px; font-size: 14px; color: #666;'>GATE PASS QR CODE</p>
                        </div>
                    </div>
                    
                    <div class='instruction'>
                        <h4>📝 Military Protocols:</h4>
                        <ul style='margin: 10px 0; padding-left: 20px;'>
                            <li>Present military ID with this gate pass</li>
                            <li>QR code scanned at exit and return</li>
                            <li>Return before expected time</li>
                            <li>Follow all security protocols</li>
                            <li>Keep this document secure</li>
                        </ul>
                    </div>
                    
                    <p><strong>Mission Success!</strong></p>
                </div>
                
                <div class='footer'>
                    <p>Military Institution Vehicle Management System</p>
                    <p>Automated Message - Do Not Reply</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
    
    private function generatePlainTextContent($recipient_name, $pass_number, $time_out, $expected_return, $destination, $purpose) {
        return "
MILITARY INSTITUTION GATE PASS
Pass Number: $pass_number

Dear $recipient_name,

Your military gate pass has been generated.

MISSION DETAILS:
Destination: $destination
Purpose: " . ucwords(str_replace('_', ' ', $purpose)) . "
Departure: " . date('M j, Y g:i A', strtotime($time_out)) . "
Expected Return: " . date('M j, Y g:i A', strtotime($expected_return)) . "

Present military ID with this gate pass.
QR code will be scanned at gate.

Mission Success!

Military Institution Vehicle Management System
        ";
    }
    
    private function saveLocalGatePass($recipient_name, $pass_number, $qr_data, $time_out, $expected_return, $destination, $purpose) {
        $filename = "gate_pass_{$pass_number}.html";
        $html_content = $this->generateEmailTemplate($recipient_name, $pass_number, $qr_data, $time_out, $expected_return, $destination, $purpose);
        
        if (file_put_contents($filename, $html_content)) {
            error_log("Gate pass saved locally as: $filename");
        } else {
            error_log("Failed to save local gate pass file");
        }
    }
}
?>